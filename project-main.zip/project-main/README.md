# Hi there 👋, I'm Suraj Singh

## 🚀 Aspiring DevOps & Cloud Engineer

Passionate about automating infrastructure, building CI/CD pipelines, and deploying scalable applications on AWS using modern DevOps tools.

---

## 👨‍💻 About Me

- 🌱 Currently learning **Advanced DevOps & Cloud Technologies**
- ☁️ Hands-on experience with **AWS**
- 🐳 Building projects using **Docker & Kubernetes**
- ⚙️ Creating CI/CD pipelines using **Jenkins**
- 🏗️ Provisioning infrastructure with **Terraform**
- 🐍 Learning **Python Automation**
- 🐧 Linux enthusiast

---

# 🛠️ Tech Stack

### Cloud

![AWS](https://img.shields.io/badge/AWS-232F3E?style=for-the-badge&logo=amazonaws&logoColor=white)

### DevOps

![Docker](https://img.shields.io/badge/Docker-2496ED?style=for-the-badge&logo=docker&logoColor=white)

![Kubernetes](https://img.shields.io/badge/Kubernetes-326CE5?style=for-the-badge&logo=kubernetes&logoColor=white)

![Jenkins](https://img.shields.io/badge/Jenkins-D24939?style=for-the-badge&logo=jenkins&logoColor=white)

![Terraform](https://img.shields.io/badge/Terraform-623CE4?style=for-the-badge&logo=terraform&logoColor=white)

![Ansible](https://img.shields.io/badge/Ansible-black?style=for-the-badge&logo=ansible)

---

### Programming

![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)

![Bash](https://img.shields.io/badge/Bash-121011?style=for-the-badge&logo=gnu-bash)

---

### Version Control

![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git)

![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github)

---

### Operating Systems

- Linux
- Ubuntu
- Amazon Linux
- Windows

---

# 🚀 Featured Projects

## 🔹 Java CI/CD Pipeline with Jenkins

Automated the build and deployment of a Java web application using Jenkins and Apache Tomcat.

**Tools Used**

- Jenkins
- Git
- GitHub
- Maven
- Apache Tomcat
- Linux

---

## 🔹 Dockerized Java Application on Amazon EKS

Containerized a Java application using Docker and deployed it on Amazon EKS with Kubernetes.

**Tools Used**

- Docker
- Kubernetes
- Amazon EKS
- Amazon ECR
- kubectl

---

## 🔹 Infrastructure as Code with Terraform

Provisioned AWS infrastructure including:

- VPC
- EC2
- Internet Gateway
- Route Tables
- Security Groups

---

## 🔹 Kubernetes Monitoring

Implemented monitoring using:

- Prometheus
- Grafana

---

## 🔹 Python Projects

- Student Management System
- Linux Automation Scripts
- File Management Utilities

---

# 📜 Certifications

- AWS Certified Cloud Practitioner *(Add your certification here)*
- CCNA

---

# 📚 Currently Learning

- Helm
- Argo CD
- GitHub Actions
- Kubernetes Security
- Python Automation

---

# 📈 GitHub Stats

> Replace `YOUR_USERNAME` with your GitHub username.

![GitHub Stats](https://github-readme-stats.vercel.app/api?username=YOUR_USERNAME&show_icons=true&theme=github_dark)

![Top Languages](https://github-readme-stats.vercel.app/api/top-langs/?username=YOUR_USERNAME&layout=compact&theme=github_dark)

![GitHub Streak](https://streak-stats.demolab.com?user=YOUR_USERNAME&theme=github-dark)

---

# 🤝 Connect With Me

- 💼 LinkedIn: https://linkedin.com/in/YOUR_USERNAME
- 💻 GitHub: https://github.com/YOUR_USERNAME
- 📧 Email: your.email@example.com

---

## 💡 Motto

> "Automate everything. Keep learning. Build solutions that scale."

⭐ Thank you for visiting my profile!























# 🚀 Java Web Application CI/CD with Jenkins & Tomcat

This project demonstrates a complete CI/CD pipeline for a Java Maven web application using Jenkins. The application is automatically built, packaged, and deployed to an Apache Tomcat server.

---

## 📌 Project Overview

The objective of this project is to automate the software delivery process using Jenkins.

Whenever code is pushed to GitHub, Jenkins performs the following tasks:

- Pulls the latest source code
- Builds the application using Maven
- Generates a WAR file
- Deploys the WAR file to Apache Tomcat
- Makes the application available through a web browser

---

## 🛠️ Technologies Used

- Jenkins
- Git & GitHub
- Maven
- Apache Tomcat
- Java
- Linux
- Bash

---

## 📂 Project Structure

```
project/
│
├── src/
├── pom.xml
├── Jenkinsfile
└── README.md
```

---

## ⚙️ CI/CD Workflow

```
Developer
      │
      ▼
GitHub Repository
      │
      ▼
Jenkins Pipeline
      │
      ▼
Maven Build
      │
      ▼
WAR File Generated
      │
      ▼
Deploy to Tomcat
      │
      ▼
Application Running
```

---

## 🚀 Pipeline Stages

1. Checkout Source Code
2. Build using Maven
3. Package WAR File
4. Deploy to Tomcat
5. Verify Deployment

---

## 📸 Screenshots

Add screenshots here:

- Jenkins Dashboard
- Successful Build
- Console Output
- Tomcat Manager
- Running Application

---

## 📚 Learning Outcomes

- Jenkins Pipeline
- Maven Build Automation
- Continuous Integration
- Continuous Deployment
- Tomcat Deployment
- Linux Commands
- GitHub Integration

---

## 👨‍💻 Author

Suraj Singh

=========================
# ☸️ Java Web Application Deployment on Amazon EKS

This project demonstrates how to containerize a Java web application using Docker and deploy it to Amazon Elastic Kubernetes Service (EKS).

The complete deployment uses Kubernetes resources such as Deployments, Services, and Load Balancers to make the application highly available.

---

## 📌 Project Overview

The project covers the complete containerization and Kubernetes deployment lifecycle.

The workflow includes:

- Build Java application
- Create Docker Image
- Push Image to Docker Hub / Amazon ECR
- Deploy to Amazon EKS
- Expose application using Kubernetes Service

---

## 🛠️ Technologies Used

- Docker
- Kubernetes
- Amazon EKS
- Amazon EC2
- Docker Hub / Amazon ECR
- kubectl
- Java
- Maven
- Linux

---

## 📂 Project Structure

```
project/
│
├── Dockerfile
├── deployment.yaml
├── service.yaml
├── pom.xml
└── README.md
```

---

## ☸️ Deployment Workflow

```
Java Source Code
        │
        ▼
 Maven Build
        │
        ▼
 Docker Image
        │
        ▼
 Docker Hub / Amazon ECR
        │
        ▼
 Amazon EKS
        │
        ▼
 Kubernetes Deployment
        │
        ▼
 LoadBalancer Service
        │
        ▼
 Application Accessible
```

---

## 🚀 Deployment Steps

1. Build Maven Project
2. Build Docker Image
3. Push Image to Registry
4. Create Kubernetes Deployment
5. Create Service
6. Access Application

---

## ☸️ Kubernetes Resources

- Deployment
- ReplicaSet
- Pods
- Service
- LoadBalancer

---

## 📸 Screenshots

Add screenshots of:

- Docker Image
- Docker Hub / Amazon ECR
- EKS Cluster
- Running Pods
- Services
- LoadBalancer
- Browser Output

---

## 📚 Learning Outcomes

- Docker Containerization
- Kubernetes Basics
- Amazon EKS
- kubectl
- Docker Image Management
- Kubernetes Deployments
- Service Exposure
- Cloud Deployment

---

## 👨‍💻 Author

Suraj Singh

